package com.itheima.service;

import com.itheima.pojo.Brand;
import com.itheima.pojo.PageBean;
import org.apache.ibatis.annotations.Param;

import java.util.List;

public interface BrandService {
    List<Brand> selectAll();

    void add(Brand brand);

    void deleteByIds(int[] ids);

    PageBean<Brand> selectByPage(int currentPage, int pageSzie);

    PageBean<Brand> selectByPageAndCondition(int currentPage, int pageSzie, Brand brand);

    //定义修改接口
    void updateById(Brand brand);

    //定义删除接口
    void deleteById(int id);
}
